# Game Jam!

This is a **WORK-IN-PROGRESS** project for the [New Year, New Skills Game Jam](https://itch.io/jam/new-year-new-skills-game-jam) hosted by Bitter Sails.

This is a tower-defense game that combines elements of resource management and survival within an island environment. 
In this game, players build walls and traps to defend against hordes of monsters that spawn during nighttime waves. 
The gameplay consists of day and night cycles, during which players can safely collect resources and set up obstacles in the daytime, while monsters attack at night. 
Success is achieved by effectively defending the base, expanding it to cover the perimeter of the island, and preventing monster spawning.
